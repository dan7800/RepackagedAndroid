package de.ecspride;

public class VarA extends General{
	@Override
	public String getInfo() {
		return man.getDeviceId(); //source
	}
}
